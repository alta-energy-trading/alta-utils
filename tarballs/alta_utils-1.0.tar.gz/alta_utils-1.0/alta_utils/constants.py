EXCHANGE_SERVER = 'https://outlook.office365.com/EWS/Exchange.asmx'
INFO_EMAIL_ADDRESS = 'henryt@arcpet.co.uk'
ERROR_EMAIL_ADDRESS = 'henryt@arcpet.co.uk'
SENDER_EMAIL_ADDRESS = 'targo.support@arcpet.co.uk'
INTERNAL_DOMAIN = 'Arcpet'
TARGO_DB_NAME = 'STG_Targo'
PRICE_DB_NAME = 'Price'
PRODUCTION_DB_SERVER = 'ArcSql'

